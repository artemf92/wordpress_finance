<? 
wp_redirect('/user/' . get_query_var('author') . '/', '301');
?>