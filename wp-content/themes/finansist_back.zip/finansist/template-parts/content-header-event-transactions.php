  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"><?= esc_html('Инвестор')?></th>
      <th scope="col"><?= esc_html('Имя транзакции')?></th>
      <th scope="col"><?= esc_html('Сумма транзакции')?></th>
      <th scope="col"><?= esc_html('Время создания')?></th>
    </tr>
  </thead>