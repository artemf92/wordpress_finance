  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"><?= esc_html('Имя инвестора')?></th>
      <th scope="col"><?= esc_html('Инвестировано / сверх')?></th>
      <th scope="col"><?= esc_html('Время инвестиции')?></th>
    </tr>
  </thead>