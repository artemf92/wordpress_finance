  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"><?= esc_html('Имя')?></th>
      <th scope="col" class="text-right"><?= esc_html('Доход')?></th>
      <th scope="col" class="text-right"><?= esc_html('Возврат инвестиций (портфель)')?></th>
      <th scope="col" class="text-right"><?= esc_html('Возврат инвестиций (сверх)')?></th>
    </tr>
  </thead>