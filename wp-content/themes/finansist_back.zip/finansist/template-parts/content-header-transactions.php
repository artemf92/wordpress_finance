  <thead>
    <tr>
      <th scope="col">№</th>
      <th scope="col"><?= esc_html('Имя транзакции')?></th>
      <th scope="col"><?= esc_html('Проект')?></th>
      <th scope="col"><?= esc_html('Сумма транзакции')?></th>
      <th scope="col"><?= esc_html('Время создания')?></th>
      <th scope="col">#</th>
    </tr>
  </thead>