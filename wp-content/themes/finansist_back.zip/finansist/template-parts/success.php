<div class="fonsa">
 <i class="bg-white border-1 border-primary color-lightgreen fa-4x fa-check fa-solid m-x-3 m-y-3"></i>
</div>