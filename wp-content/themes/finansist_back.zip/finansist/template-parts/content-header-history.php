  <thead>
    <tr>
      <th scope="col">#</th>
      <?/*<th scope="col"><?= esc_html('Тип события')?></th>*/?>
      <th scope="col"><?= esc_html('Имя события')?></th>
      <th scope="col"><?= esc_html('Сумма события')?></th>
      <th scope="col"><?= esc_html('Дата')?></th>
    </tr>
  </thead>