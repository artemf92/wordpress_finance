  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col"><?= esc_html('Имя')?></th>
      <th scope="col"><?= esc_html('Группа')?></th>
      <th scope="col"><?= esc_html('Роли')?></th>
      <th scope="col" class="centered"><?= esc_html('Сумма на руках')?></th>
      <th scope="col" class="centered"><?= esc_html('Вложено из портфеля')?></th>
      <th scope="col" class="centered"><?= esc_html('Вложено сверх')?></th>
    </tr>
  </thead>